#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(void) {
    

    char filename[100];
    printf("Enter the Filename : ");
    scanf("%s",&filename);
    char line[50];
    FILE *fp = fopen(filename, "w");

    while(1){
        char user_input[50];
        printf("Enter String : ");
        scanf("%s",&user_input);
        if(strcmp(user_input,"-1") == 0){
            fclose(fp);
            break;
        }
        else{
            fputs(user_input,fp); 
            fputs('\n',fp);
        }

        
    }
    
    
    return 0;
}