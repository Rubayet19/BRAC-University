#include <stdio.h>
struct Paratha
{
    int quantity;
    int unit_price;
};
struct Vegetable
{
    int quantity;
    int unit_price;
};
struct Mineral_Water
{
    int quantity;
    int unit_price;
};
void main(){
    struct Paratha p;
    struct Vegetable v;
    struct Mineral_Water m;
    int n;
    float sum=0;
    printf("Quantity Of Paratha: ");
    scanf("%d", &p.quantity);
    printf("Unit Price: ");
    scanf("%d", &p.unit_price);
    printf("Quantity Of Vegetable: ");
    scanf("%d", &v.quantity);
    printf("Unit Price: ");
    scanf("%d", &v.unit_price);
    printf("Quantity Of Mineral Water: ");
    scanf("%d", &m.quantity);
    printf("Unit Price: ");
    scanf("%d", &m.unit_price);
    sum= (p.quantity*p.unit_price) +(v.quantity*v.unit_price) + (m.quantity* m.unit_price);
    printf("Number of People: ");
    scanf("%d", &n);
    printf("Individual people will pay:%.2f ", sum/n);
    printf("tk");
}
