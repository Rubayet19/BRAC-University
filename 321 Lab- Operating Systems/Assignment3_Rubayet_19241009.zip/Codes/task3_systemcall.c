#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

int main(void) {


    pid_t parent,x,y,z;
    parent = getpid();
    int a = fork();
    int count = 1;
    x = getpid();
    
    if(x != parent && x%2 == 1){
    	count++;
    	int b = fork();
    	y = getpid();
    	
    	
    	if(y != parent && y != x && y%2 == 1){
    		count++;
    		int c = fork();
    		z = getpid();
    		if(z != y && z != x && z != parent && z%2 == 1){
    			count++;
    			
    		}else{
    		wait(NULL);
    		}
    	}else{
    		wait(NULL);
    	}
    }{
    	wait(NULL);
    	printf("Total process %d\n",count);
    }
    return 0;
}