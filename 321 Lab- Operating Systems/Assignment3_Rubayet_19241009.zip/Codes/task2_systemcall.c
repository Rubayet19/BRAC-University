#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main()
{
    pid_t parent,child,grandchild;

    parent = getpid();
    fork();
    child = getpid();
    if(child != parent){
        fork();
        grandchild = getpid();
        if(child != grandchild){
            printf("I am the Grandchild\n");
        }
        else{
	    wait(NULL);
            printf("I am the Child\n");
	}
        printf("I am the parent\n");
    }
    else{
	wait(NULL);
	printf("I am the parent\n");
    }

    return(0);
}