#include <stdio.h>
#include <pthread.h>

void *threadFun(void *threadId){
  static int num = 1;
  long id = (long)threadId;
  for (int i=0;i<5;i++)
    printf("Thread %ld prints %d\n",id,num++);
}


int main(void) {
  pthread_t threads[5];
  for (long i=0;i<5;i++){
    pthread_create(&threads[i],NULL,threadFun,(void*)i);
    pthread_join(threads[i],NULL);
  }
  return 0;
}
