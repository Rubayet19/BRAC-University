
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <string.h>

void *countASCII(void *input1)
{
    char *input = (char *)input1;
    int output = 0;
    int *result = malloc(sizeof(int));
    int i = 0;
    while (input[i] != '\0')
    {
        output += input[i];
        i++;
    }
    *result = output;
    return (void *)result;
}

int main()
{
    pthread_t id1, id2, id3;

    char name[20];
    char name2[20]; 
    char name3[20];
    scanf("%s",name);
    scanf("%s",name2);
    scanf("%s",name3);
    printf("For user names: %s %s %s\n", name, name2, name3);

    pthread_create(&id1, NULL, countASCII, name);
    int *count;
    pthread_join(id1, (void **)&count);

    pthread_create(&id2, NULL, countASCII, name2);
    int *count2;
    pthread_join(id2, (void **)&count2);

    pthread_create(&id3, NULL, countASCII, name3);
    int *count3;
    pthread_join(id3, (void **)&count3);

    if (*count == *count2 && *count == *count3)
    {
        printf("Youreka\n");
    }
    else if (*count == *count2 || *count == *count3 || *count2 == *count3)
        printf("Miracle\n");
    else
        printf("Hasta la vista\n");

    return 0;
}
