#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdlib.h>
#include <sys/types.h>
#include <unistd.h>


int main(void) {
    
    FILE *fp;
    int ar[10];
    fp = fopen("input.txt","r");
    fread(ar,sizeof(int),10,fp);
    fclose(fp);

    for(int i=0;i<10;i++)
    {
        printf("the number %d is ",ar[i]);
        if(ar[i]%2 == 1)
        {
            printf("odd\n");
        }
        else
        {
            printf("even\n");
        }
    
    } 
    return 0;
}