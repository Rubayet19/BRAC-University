#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdlib.h>
#include <sys/types.h>
#include <unistd.h>


int main(void) {
    

    FILE *fp;
    int ar[10];
    fp = fopen("input.txt","w");

    printf("Enter Value\n");
    for(int i=0;i<10;i++)scanf("%d",&ar[i]);

    fwrite(ar,sizeof(int),sizeof(ar),fp);
    
    fclose(fp);
    
    for(int i=0;i<10;i++){
        printf("%d\n",ar[i]);
    }

    pid_t p,c;
    p = getpid();
    fork();
    c = getpid();

    if(p != c){
        system("gcc -o sort sort.c");
        system("./sort");
    }else{
        system("gcc -o oddeven oddeven.c");
        system("./oddeven");
        
    } 
    return 0;
}