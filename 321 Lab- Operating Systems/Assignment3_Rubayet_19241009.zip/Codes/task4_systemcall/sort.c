#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdlib.h>
#include <sys/types.h>
#include <unistd.h>


int main(void) {
    
    FILE *fp;
    int ar[10];
    fp = fopen("input.txt","r");
    fread(ar,sizeof(int),10,fp);
    for(int i=0;i<10;i++)
        for(int j=i+1;j<10;j++)if(ar[i] < ar[j]){
        	int temp = ar[i];
        	ar[i] = ar[j];
        	ar[j] = temp;
        }
    for(int i=0;i<10;i++){
        printf("%d\n",ar[i]);
    }
    fclose(fp);    
    return 0;
}