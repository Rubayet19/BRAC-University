#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>


int num = 1;


void *threadFunction(void *vargp )
{
    sleep(1);
    printf("\nthread- %d running" , num);
    return NULL;
}

int main()
{
    for(int i = 0 ; i < 5 ; i++)
    {
    pthread_t thread_id;
    pthread_create(&thread_id, NULL, threadFunction, NULL);
    pthread_join(thread_id, NULL);
    printf("\nthread- %d closed\n" , num);
    num++;
    }
    exit(0);
}
