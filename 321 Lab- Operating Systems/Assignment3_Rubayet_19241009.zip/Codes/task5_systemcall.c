#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

int main(void) {


    int parent,child;
    
    parent = getpid();
    fork();
    child = getpid();
    if(child != parent){
    	
    	printf("Child process ID : %d\n",child);
    	int gc1,gc2,gc3;
    	fork();
    	gc1 = getpid();
    	if(gc1 != child){
    		
    		printf("Grand Child process ID :%d\n",gc1);
    	}else{
    		
    		fork();
    		
    		gc2 = getpid();
    		
    		if(gc2 != child){
    			
    			printf("Grand Child process ID :%d\n",gc2);
    		}else{

    			fork();
    			
    			gc3 = getpid();
    			if(gc3 != child)
    				printf("Grand Child process ID :%d\n",gc3);
    		}
    	}
    	
    }else{

    	printf("Parent process ID : %d\n",parent);
    }
    




    return 0;
}