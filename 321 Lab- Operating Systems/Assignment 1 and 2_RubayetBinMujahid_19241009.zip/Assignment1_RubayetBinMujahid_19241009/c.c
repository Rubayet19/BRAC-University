#include <stdio.h>
#include <stdlib.h>

int main(){
    char pass[50];
    int upper=0,lower=0,special=0,dig=0;
    printf("Enter Password: ");
    gets(pass);

    for(int i=0;pass[i];i++){
        if(pass[i]>=65 && pass[i]<=90){
            upper++;
        }
        else if(pass[i]>=97 && pass[i]<=122){
            lower++;
        }
        else if(pass[i]>=48 && pass[i]<=57){
            dig++;
        }
        else if(pass[i]=='_' || pass[i]=='$' ||pass[i]=='#'||pass[i]=='@'){
            special++;
        }
    }
    if(upper!=0 && lower!=0 && special!=0 && dig !=0){
        printf("OK");
    }
    else{
        if(upper==0){
            printf("Uppercase character missing\n");
        }
        if(lower==0){
            printf("Lowercase character missing\n");
        }
        if(dig==0){
            printf("Digit missing\n");
        }
        if(special==0){
            printf("Special character missing");
        }
    }

    return 0;
}