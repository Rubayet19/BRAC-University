#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{

  char email[50];
  printf("Enter Email: ");
  gets(email);
  char domain[] = "@sheba.xyz";

  char *p1, *p2, *p3;
  int j,flag=0;

  p1 = email;
  p2 = domain;

  for(int i = 0; email[i]; i++)
  {
    if(*p1 == *p2)
      {
          p3 = p1;
          for(j = 0;j<strlen(domain);j++)
          {
            if(*p3 == *p2)
            {
              p3++;p2++;
            } 
            else
              break;
          }
          p2 = domain;
          if(j == strlen(domain))
          {
             flag = 1;
            printf("Email address is okay");
          }
      }
    p1++; 
  }
  if(flag==0)
  {
       printf("Email address is outdated");
  }
return 0;
}

