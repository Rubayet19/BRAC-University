#include <stdio.h>
#include <stdlib.h>


void sub(int x,int y, int *result){
    *result=x-y;
    return;
}
void add(int x, int y, int *result){
    *result=x+y;
    return;
}
void mul(int x,int y, int *result){
    *result=x*y;
    return;
}

int main(){
    int x,y,ans;
    char op[5];
    printf("Give 2 numerical inputs: ");
    scanf("%d %d",&x,&y);
    printf("Give input for operator: ");
    scanf("%s",&op);
    if(x>y){
        sub(x,y,&ans);
    }
    else if(y>x){
        add(x,y,&ans);
    }
    else{
        mul(x,y,&ans);
    }
    printf("Ans: %d",ans);
    return 0;
}