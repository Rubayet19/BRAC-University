#include <stdio.h>
#include <string.h>
int checkifpalindrome(char *string){
   char *forward, *reverse;
   forward = string;
   reverse = forward + strlen(string) - 1;
   for (forward = string; reverse >= forward;) {
      if (*reverse == *forward) {
         reverse--;
         forward++;
      } else
         break;
   } if (forward > reverse)
      return 1;
   else
      return 0;
}
int main(){
   char str[100];
   printf("Enter Word: ");
   gets(str);
   if(checkifpalindrome(str)){
    printf("Palindrome");
   }
   else{
    printf("Not Palindrome");
   }
}