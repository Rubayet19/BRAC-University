#include <stdio.h>
#include <stdlib.h>

int main(){
    char line[255];
    FILE * fpointer=fopen("input.txt","r");
    fgets(line,255,fpointer);
    fclose(fpointer);
    char * word = strtok(line, " ");
    FILE * fpointers=fopen("output.txt", "w");
    while( word != NULL ) {
        fprintf(fpointers, word);
        fprintf(fpointers, " ");
        word = strtok(NULL, " ");
   }
   fclose(fpointers);
    return 0;
}
