file=open('task2_input.txt')
lines=file.readlines()
arr=[]
for x in lines:
    x,y=[int(v) for v in x.split()]
    arr.append(x)
    arr.append(y)


rows,cols=(arr[0],2)
assignment_list=[]
for i in range(rows):
    col=[]
    for j in range(cols):
        col.append(0)
    assignment_list.append(col)

list_count=0
for i in range(2,len(arr),2):
    assignment_list[list_count][0]=arr[i]
    assignment_list[list_count][1]=arr[i+1]
    list_count+=1

for i in range(len(assignment_list)):
    idx=i
    for j in range(i+1,len(assignment_list)):
        if assignment_list[idx][1]>assignment_list[j][1]:
            idx=j
    
    temp=assignment_list[i]
    assignment_list[i]=assignment_list[idx]
    assignment_list[idx]=temp

count=0
et=[0]*arr[1]
for i in range(arr[0]):
    if et[0]<=assignment_list[i][0] or et[1]<=assignment_list[i][0]:
        if et[0]<=assignment_list[i][0]:
            et[0]=assignment_list[i][1]
        else:
            et[1]=assignment_list[i][1]
        count+=1

print(count)