file = open("task3_input.txt")
f = file.read()
f = f.split("\n")
n = int(f[0].strip())

tasks = [int(i) for i in f[1].split()]
calls = f[2].strip()
tasks.sort()
x = 0

tj=0
tjill=0
Jack_tasks = []
a = []

for i in calls:
    if i == "J":
        a.append(tasks[x])
        tj+=a[-1]

        Jack_tasks.append(tasks[x])
        x += 1
    elif i == "j":
        a.append(Jack_tasks.pop())
        tjill+=a[-1]

print(*a, sep = "")
print("Jack will work for",tj,"hours")
print("Jill will work for",tjill,"hours")