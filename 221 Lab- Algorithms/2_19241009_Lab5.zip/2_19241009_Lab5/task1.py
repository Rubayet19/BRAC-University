file=open('task1_input.txt')
lines=file.readlines()
total=int(lines[0])
arr=[]
arr.append(total)
for x in lines[1:]:
    x,y=[int(v) for v in x.split()]
    arr.append(x)
    arr.append(y)

rows,cols=(arr[0],2)
assignment_list=[]
for i in range(rows):
    col=[]
    for j in range(cols):
        col.append(0)
    assignment_list.append(col)

list_count=0
for i in range(1,len(arr),2):
    assignment_list[list_count][0]=arr[i]
    assignment_list[list_count][1]=arr[i+1]
    list_count+=1

for i in range(len(assignment_list)):
    idx=i
    for j in range(i+1,len(assignment_list)):
        if assignment_list[idx][1]>assignment_list[j][1]:
            idx=j
    
    temp=assignment_list[i]
    assignment_list[i]=assignment_list[idx]
    assignment_list[idx]=temp

count=1
selected=[assignment_list[0]]
et=assignment_list[0][1]
for i in range(arr[0]):
    if et<=assignment_list[i][0]:
        selected.append(assignment_list[i])
        et=assignment_list[i][1]
        count+=1

print(count)
for i in selected:
    for j in i:
        print(j,end=' ')
    print('\n',end='')






