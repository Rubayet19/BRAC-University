def create_graph(input_file_location):
    with open(input_file_location, 'r') as f:
        lines = [x.strip() for x in f.readlines()]
        total_places = int(lines[0].strip())
        graph = []
        for i in range(total_places + 1):
            graph.append([])
        for connection in lines[2:]:
            connection = connection.strip()
            node1, node2 = [(node.strip()) for node in connection.split()]
            graph[int(node1)].append(node2)
        return graph


def bfs(visited, graph, node, endpoint):
    visited[int(node)] = True
    queue = []
    printed_list = [] 
    queue.append(int(node))   
    while len(queue) != 0:
        val = queue.pop(0)  
        printed_list.append(val)
        if val == int(endpoint):
            break
        for neighbour in graph[val]:
            if not visited[int(neighbour)]:
                visited[int(neighbour)] = True
                queue.append(int(neighbour))
    return printed_list


if __name__ == '__main__':
    traversal_graph = create_graph('input.txt')
    visited = [False]*len(traversal_graph)
    print(*bfs(visited, traversal_graph, '1', '12'))





