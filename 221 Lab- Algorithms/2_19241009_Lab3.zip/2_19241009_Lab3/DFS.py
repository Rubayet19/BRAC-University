printed=[]
file1 = open('input.txt', 'r')
lines = file1.readlines()
numOfNodesOrPlaces=int(lines[0])
edge=int(lines[1])

graph= [[] for i in range(numOfNodesOrPlaces+1)]
for x in lines[2:]:
    x,y=[int(v) for v in x.split()]
    graph[x].append(y)

visited=[0]*(numOfNodesOrPlaces+1)
def DFS_VISIT(graph,node):
    visited[node]=1
    printed.append(node)
    for val in graph[node]:
        if not visited[val]:                   
            DFS_VISIT(graph,val)

def DFS(graph,endPoint):
    for val in range(1,endPoint+1):
        if not visited[val]:
            DFS_VISIT(graph,val)
    for val in printed:
        if val==endPoint:
            print(val)
            break
        print(str(val), end=" ")


DFS(graph,12)