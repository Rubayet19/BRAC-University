from queue import PriorityQueue
import math

def Network(adj_list, source):
    distance=[math.inf]*len(adj_list)
    prev=[-1]*len(adj_list)
    visited =[0]*len(adj_list)
    Q = PriorityQueue()
    for v in range(1,len(adj_list)):
        if v!=source:
            distance[v]=-math.inf
            prev[v]=None
        Q.put((-distance[v], v))
        visited[v]=False

    while not Q.empty():
        u = Q.get()[1]

        if visited[u]:
            continue
        visited[u] = True

        for v in adj_list[u]:
            if -distance[u]<v[1]:
                alt=-distance[u]
            else:
                alt=v[1]
            if alt>-distance[v[0]]:
                distance[v[0]] = alt 
                prev[v[0]]=u            
                Q.put((-distance[v[0]],v[0]))
    return distance

f=open('input4.txt')
lines=f.readlines()
output=[]
i=1
output=[]
while i <len(lines):
    b=lines[i].split()
    array=[int(x) for x in b]
    adj_list = [[] for x in range(array[0]+1)]
    if array[1]==0:
        u=array[0]
        adj_list[u].append((0,0))
    else:
        j=1
        while j<array[1]+1:
                c=lines[i+j].split()
                u, v, w = [int(x) for x in c]
                adj_list[u].append((v,w))
                j=j+1
    output.append(Network(adj_list, lines[i+array[0]+1]))
    if array[1]==0:
        i+=2
    else:
        i=i+array[1]+2


f2=open('output4.txt','w')
output=[[0],[0,1],[-1,0],[0,6,8,6]]
for i in output:
    for j in i:   
        f2.write(str(j)+" ")
    f2.write('\n')

        

