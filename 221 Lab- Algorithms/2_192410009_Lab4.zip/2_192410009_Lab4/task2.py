from queue import PriorityQueue
import math

def dijkstra(adj_list, source):
    distance=[0]*len(adj_list)
    prev=[-1]*len(adj_list)
    visited =[0]*len(adj_list)
    Q = PriorityQueue()
    for v in range(1,len(adj_list)):
        if v!=source:
            distance[v]=math.inf
            prev[v]=None
        Q.put((distance[v], v))
        visited[v]=False
    

    while not Q.empty():
        u = Q.get()[1]

        if visited[u]:
            continue
        visited[u] = True

        for v in adj_list[u]:
            alt = distance[u] + v[1]
            if alt<distance[v[0]]:
                distance[v[0]] = alt 
                prev[v[0]]=u            
                Q.put((distance[v[0]],v[0]))
    prev.append(u)
    path=[i for i in prev if i!=-1]
    return path

f=open('input1.txt')
lines=f.readlines()
i=1
output=[]
while i <len(lines):
    b=lines[i].split()
    array=[int(x) for x in b]
    adj_list = [[] for x in range(array[0]+1)]
    if array[1]==0:
        u=array[0]
        adj_list[u].append((0,0))
    else:
        j=1
        while j<array[1]+1:
                c=lines[i+j].split()
                u, v, w = [int(x) for x in c]
                adj_list[u].append((v,w))
                j=j+1
    output.append(dijkstra(adj_list, 1))
    if array[1]==0:
        i+=1
    else:
        i=i+array[1]+1

f2=open('output2.txt','w')
for i in output:
    for j in i:
        f2.write(str(j)+" ")
    f2.write('\n')


        