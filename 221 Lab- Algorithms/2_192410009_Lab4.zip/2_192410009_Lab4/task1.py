from queue import PriorityQueue
import math

def dijkstra(adj_list, source):
    Q = PriorityQueue()
    visited = [False]*len(adj_list)

    distance = [math.inf]*len(adj_list)
    distance[source] = 0

    Q.put((distance[source], source))

    while not Q.empty():
        u = Q.get()[1]

        if visited[u]:
            continue
        visited[u] = True

        for v in adj_list[u]:
            alt = distance[u] + v[1]
            if alt<distance[v[0]]:
                distance[v[0]] = alt
                Q.put((distance[v[0]],v[0]))

    return distance[len(adj_list)-1]

f=open('input1.txt')
lines=f.readlines()
output=[]
i=1
while i <len(lines):
    b=lines[i].split()
    array=[int(x) for x in b]
    adj_list = [[] for x in range(array[0]+1)]
    if array[1]==0:
        u=array[0]
        adj_list[u].append((0,0))
    else:
        j=1
        while j<array[1]+1:
                c=lines[i+j].split()
                u, v, w = [int(x) for x in c]
                adj_list[u].append((v,w))
                j=j+1
    output.append(dijkstra(adj_list, 1))
    if array[1]==0:
        i+=1
    else:
        i=i+array[1]+1

f2=open('output1.txt','w')
for i in output:
    f2.write(str(i))
    f2.write('\n')

        

