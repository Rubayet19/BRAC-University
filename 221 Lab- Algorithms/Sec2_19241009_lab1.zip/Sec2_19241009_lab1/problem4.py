def Multiply_matrix(a,b,n):
    c=[]
    for i in range(n):
        c.append([0]*n)
    for j in range(n):
        for k in range(n):
            for l in range(n):
                c[j][k]+=a[j][l]*b[l][k]
    return c

matdata= open("input4.txt")
cdata=matdata.read()
c=cdata.split('\n')
for i in range(len(c)):
    c[i]=c[i].split(' ')
dim=int(c[0][0])
valA=[]
valB=[]
for a in range(dim):
    valA.append([0]*dim)
for b in range(dim):
    valB.append([0]*dim)

n=1
outs=0
while n<=dim:
    ins=0
    k=0
    while ins<dim:
        valA[outs][ins]=int(c[n][k])
        k+=1
        ins+=1
    outs+=1
    n+=1

n=dim+2
outs=0
while n<=dim+4:
    ins=0
    k=0
    while ins<dim:
        valB[outs][ins]=int(c[n][k])
        k+=1
        ins+=1
    outs+=1
    n+=1

output=Multiply_matrix(valA,valB,dim)
outdata=open("output4.txt",'w')
for i in range(0,len(output)):
    for j in range(0,len(output[i])):
        outdata.write("{} ".format(output[i][j]))
    outdata.write('\n')


