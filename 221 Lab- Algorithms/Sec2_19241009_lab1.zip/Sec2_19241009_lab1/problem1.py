no=list()
string=list()
with open('input.txt','r') as file:
    for line in file:
        for str in line.split():
            if str.isdigit():
                no.append(int(str))
            elif '.' in str:
                no.append(str)
            else:
                string.append(str)
            
inputfile=open('input.txt')
outfile=open('output.txt','w')
cdata=inputfile.read()
c=cdata.split('\n')
c = c[:-1]
recfile=open('record.txt', 'w')
palincount=0
oddcount=0
evencount=0
nopar=0

for i in no:
    if isinstance(i, int):
        if i%2==0:
            evencount+=1
            outfile.write("{} is an even parity\n".format(i))
            
        else:
            oddcount+=1
            outfile.write("{} is an odd parity\n".format(i))
            
    else:
        nopar+=1
        outfile.write("{} is not a parity\n".format(i))
        
        
            
def palindrome(word):
    n=len(word)
    for i in range(0,n):
        if word[i]!=word[n-1-i]:
            return False
    return True

for i in string:
    palindrome(i)
    if palindrome(i)==True:
        palincount+=1
        outfile.write("{} is a palindrome\n".format(i))    
    else:
        outfile.write("{} is not a palindrome\n".format(i))


total=len(c)
oddper=(oddcount/total)*100
evenper=(evencount/total)*100
noper=(nopar/total)*100
palind=(palincount/total)*100
nPalind=100-palind

recfile.write("Percentage of odd parity: {}%\n".format(int(oddper)))
recfile.write("Percentage of even parity: {}%\n".format(int(evenper)))
recfile.write("Percentage of no parity: {}%\n".format(int(noper)))
recfile.write("Percentage of palindrome: {}%\n".format(int(palind)))
recfile.write("Percentage of non-palindrome: {}%\n".format(int(nPalind)))



    
    