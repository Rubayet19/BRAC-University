f=open('input2.txt')
s1=f.readline()
s2=f.readline()
s3=f.readline()

def LCS(X, Y, Z,):
    m=len(X)
    n=len(Y)
    o=len(Z)
    M = [[[0 for i in range(o+1)] for j in range(n+1)]
         for k in range(m+1)]

    for i in range(m+1):
        for j in range(n+1):
            for k in range(o+1):
                if (i == 0 or j == 0 or k == 0):
                    M[i][j][k] = 0
                     
                elif (X[i-1] == Y[j-1] and
                      X[i-1] == Z[k-1]):
                    M[i][j][k] = M[i-1][j-1][k-1] + 1
 
                else:
                    M[i][j][k] = max(max(M[i-1][j][k],
                    M[i][j-1][k]), M[i][j][k-1])
                                    
 

    return M[m][n][o]
 
print(LCS(s1, s2, s3))