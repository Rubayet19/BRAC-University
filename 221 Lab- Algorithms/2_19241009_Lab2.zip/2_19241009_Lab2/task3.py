f1=open('input3.txt')
n=int(f1.readline())
id=f1.readline().split()
id=[int(x) for x in id]
marks=f1.readline().split()
marks=[int(x) for x in marks]

for j in range(n):
    key = marks[j]
    temp = id[j]
    i = j-1
    while i>=0 and marks[i]<key :
        marks[i+1] = marks[i]
        id[i+1] = id[i]
        i = i-1
    marks[i+1] = key
    id[i+1] = temp

f2=open('output3.txt','w')
for i in range(n):
    f2.write(str(id[i])+ ' ')