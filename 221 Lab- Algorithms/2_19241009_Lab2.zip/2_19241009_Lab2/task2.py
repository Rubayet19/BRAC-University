f1=open('input2.txt')
a=f1.readline().split()
a=[int(x) for x in a]
array=f1.readline().split()
array=[int(x) for x in array]

def selectionSort(arr,a):
    for i in range(a[0]):
        min=i
        for j in range(i+1, a[0]):
            if arr[j]<arr[min]:
                min=j
        arr[i],arr[min]=arr[min],arr[i]

selectionSort(array,a)

f2=open('output2.txt','w')
for i in range(a[1]):
    f2.write(str(array[i])+ ' ')



