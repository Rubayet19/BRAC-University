f1=open('input1.txt')
a=f1.readlines()
b=a[1].split()
array=[int(x) for x in b]
f2=open('output.txt','w')
flag=0
def bubbleSort(arr):
    for i in range(len(arr)-1):
        for j in range(len(arr)-i-1): 
            if arr[j] > arr[j+1]:
                arr[j+1],arr[j]=arr[j],arr[j+1]
                flag=1
        if flag==0:     
            break
#The best case is when the array is already sorted
#For a single complete cycle of j iteration if no swapping takes place then flag will remain 0 and then we will break out of the for loops, because the array has already been sorted. So no need to do the whole i iteration           


bubbleSort(array)
for i in array:
    f2.write(str(i)+" ")